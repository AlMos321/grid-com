<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Admin Panel</div>

                    <div class="panel-body">
                        Catalogs
                        <a href="/admin/create/catalog">create new</a>
                        <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <p><?php echo e($c->name); ?> <span><a href="/remove/catalog?id=<?php echo e($c->id); ?>">dell</a></span> <span><a href="/update/catalog?id=<?php echo e($c->id); ?>">update</a></span></p>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>