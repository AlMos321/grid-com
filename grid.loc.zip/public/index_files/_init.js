window.lpg = {
    apps: {
        accounts: {},
        api: {},
        pages: {}
    },
    vox: {},
    utils: {}
};
