@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Admin Panel</div>

                    <div class="panel-body">
                        Catalogs
                        <a href="/admin/create/catalog">create new</a>
                        @foreach($catalogs as $c)
                            <p>{{$c->name}} <span><a href="/remove/catalog?id={{$c->id}}">dell</a></span> <span><a href="/update/catalog?id={{$c->id}}">update</a></span></p>
                         @endforeach
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
